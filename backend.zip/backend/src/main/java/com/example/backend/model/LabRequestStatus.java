package com.example.backend.model;

public enum LabRequestStatus {
    PENDING,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
