package com.example.backend.exception;

public class PrescriptionException extends RuntimeException {
    public PrescriptionException(String message) {
        super(message);
    }
}
