package com.example.backend.model;

public enum Role {
    DOCTOR,
    PATIENT,
    LABTECH
}
